# Letsgrowmore
Group of projects completed by me as a part of Intern at LGM

Author Details:

Name : N KALYAN SAI

Position : Web Developer Intern, Let's Grow More

Badges : LGMVIP

--------------------------------------------------------------

Project 1

Name : Freelance Service

Type : Frontend

Techs : HTML, CSS, JavaScript, Bootstrap.

Start Date : 01.07.2021

End Date : 07.07.2021

Status : Completed
--------------------------------------------------------------

Project 2

Name : College marks display

Type : fullstack

Techs : HTML, CSS, JavaScript, Bootstrap,PHP,Mysql.

Start Date : 07.07.2021

End Date : 13.07.2021

Status : Completed
------------------------------------------------------------

